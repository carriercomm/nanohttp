$::PAGE::sHead = '<HTML>
<HEAD>
<TITLE>nanoHttp</TITLE>
<STYLE>
A { text-decoration : underline; }
A:VISITED { text-decoration : underline; }
A:HOVER { text-decoration : underline; }
TD { font-family : Arial, Helvetica, sans-serif; font-size : 14px; }
.default { font-family : Arial, Helvetica, sans-serif; font-size : 14px; }
.bdefault { font-family : Arial, Helvetica, sans-serif; font-size : 14px; font-weight : bold; }
.smaller { font-family : Arial, Helvetica, sans-serif; font-size : 14px; }
.nav { font-family : Arial, Helvetica, sans-serif; font-size : 14px; }
.bnav { font-family : Arial, Helvetica, sans-serif; font-size : 14px; font-weight : bold; }
.foot { font-family : Arial, Helvetica, sans-serif; font-size : 13px; }
.sectionhead { font-family : Arial, Helvetica, sans-serif; font-size : 18px; font-weight : bold; }
.title { font-family : Arial, Helvetica, sans-serif; font-size : 20px; font-weight : bold; }
H1 { font-family : Arial, Helvetica, sans-serif; font-size : 18px; font-weight : bold; }
H2 { font-family : Arial, Helvetica, sans-serif; font-size : 16px; font-weight : bold; }
H3 { font-family : Arial, Helvetica, sans-serif; font-size : 14px; font-weight : bold; }
pre { font-family : Arial, Helvetica, sans-serif; background-color : #CCCCCC; font-size : 13px; }

</STYLE>
</HEAD>
<BODY BGCOLOR="#FFCC00" TEXT="#000000" TOPMARGIN=5 LEFTMARGIN=2 MARGINWIDTH=5 MARGINHEIGHT=5>
<CENTER>
<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>
	<TR>
		<TD colspan="3"><IMG SRC="images/logo.gif" WIDTH=88 HEIGHT=31 BORDER=0 HSPACE=0 VSPACE=5></TD>
		<TD colspan="4"></TD>
	</TR>
	<TR VALIGN="BOTTOM">
		<TD ROWSPAN=2 BGCOLOR="#000000"><IMG SRC="images/p0.gif" BORDER=0 WIDTH=1 HEIGHT=400 HSPACE=0 VSPACE=0></TD>
		<TD BGCOLOR="#000000"><IMG SRC="images/p0.gif" BORDER=0 WIDTH=400 HEIGHT=1 HSPACE=0 VSPACE=0></TD>
		<TD BGCOLOR="#000000"><IMG SRC="images/p0.gif" BORDER=0 WIDTH=1 HEIGHT=1 HSPACE=0 VSPACE=0></TD>
		<TD ROWSPAN=4 BGCOLOR="#663300" VALIGN="TOP"><IMG SRC="images/pb.gif" BORDER=0 WIDTH=1 HEIGHT=3 HSPACE=0 VSPACE=0></TD>
		<TD ROWSPAN=5 BGCOLOR="#996600" VALIGN="TOP"><IMG SRC="images/pb.gif" BORDER=0 WIDTH=1 HEIGHT=4 HSPACE=0 VSPACE=0></TD>
		<TD ROWSPAN=6 BGCOLOR="#999900" VALIGN="TOP"><IMG SRC="images/pb.gif" BORDER=0 WIDTH=1 HEIGHT=4 HSPACE=0 VSPACE=0></TD>
		<TD ROWSPAN=7 BGCOLOR="#CC9900" VALIGN="TOP"><IMG SRC="images/pb.gif" BORDER=0 WIDTH=1 HEIGHT=5 HSPACE=0 VSPACE=0></TD>
	</TR>
	<TR>
		<TD BGCOLOR="#FFFFFF" ALIGN="LEFT" VALIGN="TOP">
			<TABLE HEIGHT=140 width="100%" BORDER=0 CELLSPACING=8 CELLPADDING=0 VALIGN="TOP">
				<TR VALIGN="TOP">
					<TD CLASS="nav" >

                        <a href="index.html">nanoHttp</a> | 
                        <a href="examples.html">Examples</a> | 
                        <a href="docu.html">Docu</a> |
                        <a href="download.html">Download</a>
                    </TD>
                </TR>
				<TR >
					<TD CLASS="default" VALIGN="TOP" WIDTH=400>
<!-- Content -->
';
out $::PAGE::sHead;
