#!/usr/bin/perl -T

# nanoHttp 0.1
# kurmis@gmx.de

use warnings;
use strict;

use IO::Socket::INET;

my $SERVER_PORT = 8080;
my %hMimeTypes = (
    "txt" => "text/plain",
    "html" => "text/html",
    "htm" => "text/html",
    "jpg" => "image/jpeg",
    "gif" => "image/gif"
);

$INC[@INC] = "lib/";

sub _print {  print shift; }
sub _printf {  
    (my $file,my $content)= @_; 
    print $file $content
}
_print "Starting http-Server\n";

# Open Socket
my $server = IO::Socket::INET->new(
    LocalPort => $SERVER_PORT,
    Proto     => 'tcp',
    Listen    => SOMAXCONN
  )
  or die "Could not listen to port $SERVER_PORT : $!";

_print "Lisening for requests on port $SERVER_PORT\n";

local $::OUT_BUFFER = "";
sub print { $::OUT_BUFFER.=shift; }
sub out { $::OUT_BUFFER.=shift; }


while (1) {

    # Auf eine Verbindung warten
    die "Fehler in accept: $!"
      unless defined( my $client = $server->accept() );
    _printf($client,http($client));
}

sub sGetContentType {
	(my $sFileName) = @_;

	my $sContentType = "";
    my $ext;
    my $type;
    while (($ext,$type) = each(%hMimeTypes)) {
    	if ($sFileName =~ /.$ext/i) {
    		$sContentType 	= $type;
    	}
    }
    if (!$sContentType) {
        $sContentType = "text/plain";
    }
	return $sContentType;
}


# Die Behandlung des Protokolls
sub http {
    my $sock = shift;
    my $sRequest = <$sock>;
	my @aRequest = split(/ /,$sRequest);
    my $sFileName    = $aRequest[1];

   	if (!$sFileName) {
        $sFileName = "/";
    }
   	if ($sFileName =~ m|/$|) {
        $sFileName .= "index.html";
    }
	my $sReturn  = "";
    my $sReturnHead = "";
    my $sReturnBody = "";
	my $sStatus  = "";
    my $sContentType = "";
	my $sExt = "";
    my $EVAL_ERROR = "";
    my $EVAL_ERROR_ERROR = "ISE processing ISE page\n";

    sub parseFile {
        my $pRet = shift;
        my $pERR = shift;
        ${$pRet} =~ s|<%(.*?)%>| $::OUT_BUFFER = ""; eval $1;${$pERR}.=$@; $::OUT_BUFFER|seg;
    }
	if ( open(FH,"html".$sFileName) ) {		
		## http-Status setzen
    	$sStatus 		= "200 OK";
	} elsif ( open(FH,"html"."/404.html") ) {
        ## 404-Seite holen
        $sStatus 		= "404 Not Found";
        $sFileName = "404.html";
    }
    if (!$sStatus){
    	$sStatus = "404 Not Found";
    	$sReturn = "Fehler: Datei nicht gefunden.";
	} else {
		$sContentType = sGetContentType($sFileName);
		## Datei zeilenweise auslesen
		while (<FH>) {
			$sReturn .= $_;
		}
		close(FH);
    }

    if ( $sReturn ) {
        ##$sReturn = 
        parseFile(\$sReturn,\$EVAL_ERROR);
    }

    if ( $EVAL_ERROR ) {
        $sReturn = "";
       	$sStatus = "500 Internal Server Error";
        if ( open(FH,"html"."/500.html") ) {
            $sFileName = "500.html";
            $sContentType = sGetContentType($sFileName);
		    while (<FH>) {
			     $sReturn .= $_;
		    }
            close(FH);
            $EVAL_ERROR_ERROR = "";
            parseFile(\$sReturn,\$EVAL_ERROR_ERROR);
        }
        _print "\$EVAL_ERROR_ERROR=$EVAL_ERROR_ERROR\n";
        if ($EVAL_ERROR_ERROR) {
             $sContentType = "text/plain";
             $sReturn = "Internal Server Error:\n\n$EVAL_ERROR";
        }
    }

    $sReturnHead .= "HTTP/1.1 $sStatus\n";
    $sReturnHead .= "Server: nanoHttp\n";
    $sReturnHead .= "Connection: close\n";
    $sReturnHead .= "Content-Type: $sContentType\n";
    $sReturnHead .= "Content-location: $sFileName\n";
    $sReturnHead .= "Content-Length: ".length($sReturn)."\n";
    $sReturnHead .= "\n";
    _print $sRequest.$sReturnHead;
    return $sReturnHead.$sReturn;
}
